program JediInstaller;

uses
  Forms,
  JclInstall in 'JclInstall.pas',
  JediInstallIntf in 'JediInstallIntf.pas',
  JediInstallerMain in 'JediInstallerMain.pas' {MainForm},
  ProductFrames in 'ProductFrames.pas' {ProductFrame: TFrame},
  JclBorlandTools in '..\source\common\JclBorlandTools.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.Title := 'JEDI Installer';
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
